// João Vitor Moura Figueiredo
// executar seu próprio código C na placa FPGA (com argumentos) | Eh triangulo?

int eh_triangulo(register int x, register int y, register int z) {
   register int s = 1;
   if(x+y<=z)
      s = 2;
   else if(x+z<=y)
      s = 2;
   else if(z+y<=x)
      s = 2;
   
   return s;
}
