// João Vitor Moura
// executar seu próprio código C na placa FPGA (com argumentos) | Eh triangulo?

int eh_triangulo(register int x, register int y, register int z);