// João Vitor Moura
// executar seu próprio código C na placa FPGA (com argumentos) | Eh triangulo?
#include "triangulo.h"

void __attribute__ ((naked)) main() {
    volatile int * const io = (int *)(0x3F*4);

    int sideA, sideB, sideC;

    sideA = *io; // Pega um possivel lado de SWI[4:0]
    sideB = *io; // Pega um possivel lado de SWI[4:0]
    sideC = *io; // Pega um possivel lado de SWI[4:0]

    /*
       A partir dos três valores possíveis de lados de um triângulo, verifica se é possível gerar um triângulo
       com esses valores.

       1 -> é possível gerar um triangulo
       2 -> não é possível gerar um triangulo
    */
    *io = eh_triangulo(sideA, sideB, sideC); // Resultado da análise irá para saída - LED[4:0]
}