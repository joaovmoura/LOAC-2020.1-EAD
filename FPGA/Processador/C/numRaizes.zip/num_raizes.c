// João Vitor Moura Figueiredo
// executar seu próprio código C na placa FPGA (com argumentos) | Eh triangulo?

int num_raizes(register int x, register int y, register int z) {
   double delta = (y*y) - (4*x*z);
   if(delta<0)
      return 1;
   else if(delta==0)
      return 2;
   else
      return 3;
}
