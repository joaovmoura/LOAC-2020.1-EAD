// João Vitor Moura
// executar seu próprio código C na placa FPGA (com argumentos) | Eh triangulo?

int num_raizes(register int x, register int y, register int z);