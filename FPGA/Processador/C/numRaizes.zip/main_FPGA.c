// João Vitor Moura
// executar seu próprio código C na placa FPGA (com argumentos) | Numero de raízes da equação
#include "num_raizes.h"


void __attribute__ ((naked)) main() {
    volatile int * const io = (int *)(0x3F*4);

    int A, B, C;

    A = *io; // Pega o valor de a de SWI[4:0]
    B = *io; // Pega o valor de b de SWI[4:0]
    C = *io; // Pega o valor de c de SWI[4:0]

    /*
       A partir dos valores dos coeficientes de uma eq. do segundo grau, calcula o numero de raízes

       1 -> sem raízes reais
       2 -> uma raiz
       3 -> duas raizes

      obs: o calculo demora um pouco a acontecer
    */
    *io =num_raizes(A, B, C); // Resultado da análise irá para saída - LED[4:0]
}